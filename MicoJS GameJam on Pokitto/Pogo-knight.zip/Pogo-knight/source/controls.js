// controls.js

var a_pressed = 0;

// class Button {
//     constructor() {
//         this.count = 0;
//     }
//     update(val) {
//         this.count = val ? this.count + 1 : 0;
//     }
//     pressed() {
//         return this.count == 1;
//     }
//     held() {
//         return this.count > 0;        
//     }
// }

// const btn_a = new Button();
// const btn_b = new Button();
// const btn_c = new Button();
// const btn_up = new Button();
// const btn_down = new Button();
// const btn_left = new Button();
// const btn_right = new Button();

// function update_controls() {
//     btn_a.update(A);
//     btn_b.update(B);
//     btn_c.update(C);
//     btn_up.update(UP);
//     btn_down.update(DOWN);
//     btn_left.update(LEFT);
//     btn_right.update(RIGHT);
// }