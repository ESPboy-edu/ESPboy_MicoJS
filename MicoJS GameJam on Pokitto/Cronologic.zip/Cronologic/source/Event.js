// Event.js

class Event {
    constructor() {
        this.dt = 0;
        this.input = new Array(6);        
    }   
}

