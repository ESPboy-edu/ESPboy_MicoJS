// Particles.js

class Particles {
    constructor() {
    }

    update(time) {
    }

    render() {
    }
}

